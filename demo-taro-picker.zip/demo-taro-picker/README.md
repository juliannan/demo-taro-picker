# 东东企业家小程序
## 打包
```bash
# 本地调试
npm run dev:weapp

# 打生产包
npm run build:weapp

```

## 版本
因为小程序线上的唯一性，只存在一个生产环境，以及按开发者区分上传多个体验包，并且可将其中一个体验包在后台设置为体验版。代码使用git tag管理代码版本，要求微信生产环境的版本与git仓库中的tag一一对应，如当微信存在版本1.0.0、1.0.1、2.0.0，git仓库中也存在v1.0.0、v1.0.1、v2.0.0.

<font size=5 color=red>打tag时要同步给其他开发人员，避免漏掉代码</font>

---

### 基于git主干分支开发一个新特性
```bash
# 1. 切换到主干分支
git checkout master
# 2. 拉取最新代码
git pull
# 3. 拉取一个新特性分支
git checkout -b feat-branch-name
# 4. 开发完成后切换到主干分支
git checkout master
# 5. 合并开发分支代码
git merge --no-ff 开发分支
# 6. 打体验包
npm run build:weapp
# 7. 上传代码并通过测试、微信上线后，打与微信指定版本相同的tag，如当前微信指定版本为1.0.0
git tag v1.0.0
# 8. 提交tag
git push origin v1.0.0
```


### 在线版本问题修复git操作
```bash
# 1. 基于当前在线版本tag创建分支，不要直接从master分支拉取最新代码，会造成代码污染（注意：以单一特性为粒度创建，修复问题分支为临时分支，非必要临时分支无须上传至远和仓库）
git branch hotfix-new-branchname tagname
# 2. 修复完成后在当前分支打体验包
npm run build:weapp
# 3. 上传代码并通过测试、微信上线后，打与微信指定版本相同的tag，如当前微信指定版本为1.0.1
git tag v1.0.1

# 4. 将当前修复的commit同步至主干分支
# 4.1 查询本次改动的commit
git log
# 4.2 切换至主干分支
git checkout master
# 4.3 将开发分支修复的commit同步至主干分支
git cherry-pick commit-id1 commit-id2
# 4.4 查看版本冲突
git status
# 4.5 无冲突或者解决冲突后提交操作
git push

# 删除修复问题分支，因为已无实际作用
git branch -d hotfix-branch-name

```

---


## FAQ
1. 如何快速获取当前登录状态？
   <br>
   ```js
   import { computed } from "vue";
   import { useStore } from "vuex";
   import loginMixin from '@/mixins/login';

   // 植入mixins
   mixins: [loginMixin],
   setup() {
     // 连接状态树
    const store = useStore();
    const isLogin = computed(() => store.state.isLogin);

    // vue3 ref对象，在js中取value
    console.log(isLogin.value); 
   }
   ```
2. 如何唤起登录插件？
   <br>
   ```js
   import { jumpLoginAndUrl } from "@/utils/tools";

   // pageType：默认redirectTo,可选值：h5、switchTab、reLaunch。例：首页若为多tab页面，请使用switchTab
   jumpLoginAndUrl(url, pageType);
   ```
3. 如何打开支持京东pin登录态的H5页面?
   <br>
   ```js
   import loginUtils from '@/pages/login/util';
   const url = 'https://home.m.jd.com/myJd/newhome.action';

   /**
    * 打开成功回调函数
    * @param {?Object} res 可选项，包含一个eventChannel对象，可以与打开页面进行通信，详见微信wx.navigateTo
    */
   function successCb({ eventChannel }) {
     console.log('成功!')

     // 可以手动上报一些埋点数据

     // 也可以与子页面进行EventChannel的通信
     // eventChannel.emit('eventName', { data: 'test' })
   }

   // 打开失败回调函数
   const failCb() {
     console.log('失败!')
   }
   
   // 栈底打开H5,返回操作跳转至小程序主页
   loginUtils.redirectToH5({ page: url, successCb, failCb });
   // 栈顶打开H5,返回操作跳转至上一页面
   loginUtils.navigateToH5({ page: url, successCb, failCb });
   ```
4. 统一固钉按钮表单使用方法
   <br>
   ```js
   import AffixForm from '@/components/affix-form';

   <!-- 支持监听【submit】事件 -->
   <!-- 支持自定义表单【按钮文案】，默认为：提交 -->
   <affix-form
      @submit="handleClick"
      buttonText="立即咨询">

      <!-- 图片列表延迟加载使用方法 -->
      <image v-for="(imgUrl, index) in imgs"
        :key="index"
        :lazyLoad="true"
        :src="imgUrl"
        mode="widthFix"
        />

    </affix-form>
   ```
5. etc.
