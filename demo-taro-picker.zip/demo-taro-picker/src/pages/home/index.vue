<template>
  <view class="jdd-picker-wrap">
    <nut-popup
      position="bottom"
      v-model:visible="show"
      closeable
      :overlay-style="{backgroundColor:'rgba(0,0,0,0.8)'}"
      :style="{height:'50%',backgroundColor:'rgba(27,27,27,1)'}"
    >
      <picker-view indicator-style="height: 30px;" style="width: 100%; height: 300px;" :value="value" @change="onChange">
        <picker-view-column>
          <view v-for="(item, index) in list" :key="index">{{item}}年</view>
        </picker-view-column>

      </picker-view>
    </nut-popup>
  </view>
</template>
<script>
  import {ref, reactive, toRefs, onMounted, computed} from 'vue';
  import Taro from '@tarojs/taro';
  export default{
    setup(){
      const state = reactive({
        show:true,
        list:[
          "软件/互联网",
          "游戏",
          "金融服务",
          "政府"
        ]
      })
      return{
        ...toRefs(state)
      }
    }
  }
</script>
<style lang="scss">
  .jdd-picker-wrap{
    //样式覆盖
    .scroll-view-item-cus{
      height: 56px;
      line-height: 56px;
      font-size: 14px;
      font-family: PingFang-SC;
      font-weight: bold;
      color: rgba(255,255,255,0.6);
      padding: 0 16px;
    }
  }
</style>