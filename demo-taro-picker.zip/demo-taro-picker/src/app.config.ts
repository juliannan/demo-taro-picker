let pages = [
  'pages/home/index', // 首页
];

export default {
  pages: pages,
  window: {
    backgroundTextStyle: 'light',
    navigationBarBackgroundColor: '#fff',
    navigationBarTitleText: '京东科技企服中心',
    navigationBarTextStyle: 'black'
  }
}
