import { createApp } from 'vue'

import { Button, Toast,Input , Tabbar, Cell, Icon, InfiniteLoading, Avatar,Steps,Dialog ,Popup } from '@nutui/nutui-taro';

//主题定制
import '@nutui/nutui-taro/dist/styles/themes/default.scss';

const App = createApp({
  onLaunch(){},
  // 入口组件不需要实现 render 方法，即使实现了也会被 taro 所覆盖
  onHide(){
    console.log("onHide")
  }
})
App
  .use(Button)
   .use(Toast)
   .use(Input)
   .use(Tabbar)
   .use(Cell)
   .use(Icon)
   .use(InfiniteLoading)
   .use(Avatar)
   .use(Steps)
  .use(Dialog)
  .use(Popup)

export default App
